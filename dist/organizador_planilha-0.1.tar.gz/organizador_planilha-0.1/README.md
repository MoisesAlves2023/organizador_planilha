# Organizador de Planilhas

Este pacote organiza planilhas por uma coluna específica usando `pandas`. Suporta arquivos `.csv` e `.xlsx`.

## Instalação

Você pode instalar este pacote via pip:

```bash
pip install organizador_planilha
